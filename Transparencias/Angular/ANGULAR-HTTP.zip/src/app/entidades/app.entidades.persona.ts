
export class Persona {

    public constructor(public id:number=0,
                       public nombre:string='',
                       public direccion:string='',
                       public telefono:string='',
                       public correoE:string=''){
    }

}
