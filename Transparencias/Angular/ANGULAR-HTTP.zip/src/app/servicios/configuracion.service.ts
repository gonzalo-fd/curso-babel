
export class ConfiguracionService{
    //Los componentes dinámicos pertenecen a los objetos 
    //Los componentes estáticos pertenecen a la CLASE
    public static url:string = "http://localhost:7000"

    private constructor(){
    }

}