exports.crearError = function(codigo, texto, descripcion){
    return { codigo      : codigo, 
             texto       : texto,
             descripcion : descripcion }
}


