package com.modelo.persistencia;

import org.springframework.stereotype.Repository;

public class DaoUsuarioArrayList {

}
